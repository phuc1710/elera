// ignore: avoid_classes_with_only_static_members
class EndPoints {
  EndPoints._();

  static const String baseUrl = '';
  static const String signIn = '/sign_in';
  static const String signUp = '/sign_up';
}
